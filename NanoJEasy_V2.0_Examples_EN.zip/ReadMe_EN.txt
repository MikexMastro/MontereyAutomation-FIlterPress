These NanoJ Example Codes are based on our experience with typical user requirements in a wide range
of industrial applications and is provided without guarantee regarding correctness and completeness.
They serve as general guidance and should not be construed as a commitment of Nanotec to guarantee their
applicability to the customer application without additional tests under the specific conditions
and – if and when necessary – modifications by the customer.

The responsibility for the applicability and use of a NanoJ Example Code in a particular
customer application lies solely within the authority of the customer.
It is the customer's responsibility to evaluate, investigate and decide,
whether an Example Code is valid and suitable for the respective customer application, or not.
Defects resulting from the improper handling of devices and modules are excluded from the warranty.
Under no circumstances will Nanotec be liable for any direct, indirect, incidental or consequential damages
arising in connection with the Example Codes provided. In addition, the regulations regarding the
liability from our Terms and Conditions of Sale and Delivery shall apply.


in example 1 the velocity mode will be selected and the state machine will be started, the motor runs automatically.

in example 2 a enable input is added, to start the motor manually.

in example 3 the function analog input is added, there the speed can be set

in example 4 the output will be switched, depending on whether the speed is > or < than 200 rpm

in example 5 the clock-direction mode will be selected, the state machine will be started and the enable input at input 4 is added

example 6 is the same like example 3 + define of max speed, scaling, filter and play near 0

in example 7 the position mode will be selected and the motor will move between 2 positions that can be set via "VMM Input" Objects (for exmaple in the configuration file)

in example 8 the digital inputs are used to select betweeen various movement records (position mode) and start them. At power up there is an automatical homing done.  

in example 9 V1 the position mode will be selected and started

in example 9 V2 the position mode will be selected and started, after the input 1 is triggered, the motor moves to a set position (flagposition mode)

in example 9 V3 the position mode will be selected and started, after the input 1 is triggered, the motor moves to a analog set position (flagposition mode)